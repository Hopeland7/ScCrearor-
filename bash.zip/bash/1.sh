clear
php 1b.php
echo "      [ @# UNTUK JPG KETIK JEP TERUS PILIH PILIH DEH ]"
read -p "PIL [###]>" pil;

if [ $pil = 1 ] || [ $pil = 1 ]
then
python2 ah.py
fi

if [ $pil = 2 ] || [ $pil = 2 ]
then
python2 uh.py
fi


if [ $pil = 3 ] || [ $pil = 3 ]
then
python2 eh.py
fi


if [ $pil = 4 ] || [ $pil = 4 ]
then
python2 oh.py
fi

if [ $pil = 5 ] || [ $pil = 5 ]
then
python2 ih.py
fi


if [ $pil = JEP ] || [ $pil = jep ]
then
sh jep.sh
fi

if [ $pil = 6 ] || [ $pil = 6 ]
then
python2 xer.py
fi

if [ $pil = x ] || [ $pil = X ]
then
pyrhon2 X.py
fi
