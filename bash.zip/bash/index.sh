read -p "[■#####]>> " g;

if [ $g = A ] || [ $g = a ]
then
sh 1.sh
fi

if [ $g = b ] || [ $g = B ]
then
sh 1e.sh
fi

if [ $g = c ] || [ $g = C ]
then
php nick.php
sh ulang.sh
fi


if [ $g = i ] || [ $g = I ]
then
php info.php
sh ulang.sh
fi
