clear
php b.php
echo "      [ @# UNTUK JPG KETIK JEP TERUS PILIH PILIH DEH ]"
read -p "PIL [###]>" pil;

if [ $pil = 1 ] || [ $pil = 1 ]
then
python2 1ah.py
fi

if [ $pil = 2 ] || [ $pil = 2 ]
then
python2 2uh.py
fi


if [ $pil = 3 ] || [ $pil = 3 ]
then
python2 3h.py
fi


if [ $pil = 4 ] || [ $pil = 4 ]
then
python2 4e.py
fi

if [ $pil = 5 ] || [ $pil = 5 ]
then
python2 5h.py
fi

if [ $pil = x ] || [ $pil = X ]
then
pyrhon2 X.py
fi

