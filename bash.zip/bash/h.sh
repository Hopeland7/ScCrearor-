
clear

echo "         __                                    _=,_    _____________"
echo "      __/0 \_                                o_/0 / \__| JALAN JALAN AH|"
echo "      \_ __  \                                \__ |  /   -------------"
echo "          /   \                                = | -\ "
echo "    __   //\   \                               /    '-,."
echo " __/o \-//--\   \_/                            \ |_   _'-. /"
echo " \____  ___  \  |                               |/ \_(   |'"
echo "     ||   \ |\ |XerXez77                       C/ ,--___/"
echo "    _||   _||_||                             ~~~~  wwww~~~•"
echo "  ~~~~ wwwwww   w"
sleep 0,9
clear
echo "         __                                    _=,_    _____________"
echo "      __/0 \_                              o_/0 / \__| JALAN JALAN AH|"
echo "      \_ __  \                              \__ |  /   -------------"
echo "          /   \                              = | -\ "
echo "    __   //\   \                             /    '-,."
echo " __/o \-//--\   \_/                          \ |_   _'-. /"
echo " \____  ___  \  |                             |/ \_(   |'"
echo "     ||   \ |\ |XerXez77                     C/ ,--___/"
echo "    _||   _||_||                           ~~~~  wwww~~~•"
echo "  ~~~~ wwwwww   w"
sleep 0,9
clear

echo "         __                                 _=,_    _____________"
echo "      __/0 \_                            o_/0 / \__| JALAN JALAN AH|"
echo "      \_ __  \                            \__ |  /   -------------"
echo "          /   \                            = | -\ "
echo "    __   //\   \                           /    '-,."
echo " __/o \-//--\   \_/                        \ |_   _'-. /"
echo " \____  ___  \  |                           |/ \_(   |'"
echo "     ||   \ |\ |XerXez77                   C/ ,--___/"
echo "    _||   _||_||                         ~~~~  wwww~~~•"
echo "  ~~~~ wwwwww   w"
sleep 0,9
clear

echo "         __                             _=,_    _____________"
echo "      __/0 \_                        o_/0 / \__| JALAN JALAN AH|"
echo "      \_ __  \                        \__ |  /   -------------"
echo "          /   \                        = | -\ "
echo "    __   //\   \                       /    '-,."
echo " __/o \-//--\   \_/                    \ |_   _'-. /"
echo " \____  ___  \  |                       |/ \_(   |'"
echo "     ||   \ |\ |XerXez77               C/ ,--___/"
echo "    _||   _||_||                     ~~~~  wwww~~~•"
echo "  ~~~~ wwwwww   w"
sleep 0,9
clear

echo "         __                           _=,_    _____________"
echo "      __/0 \_                      o_/0 / \__| JALAN JALAN AH|"
echo "      \_ __  \                      \__ |  /   -------------"
echo "          /   \                      = | -\ "
echo "    __   //\   \                     /    '-,."
echo " __/o \-//--\   \                    \ |_   _'-. /"
echo " \____  ___  \  |                     |/ \_(   |'"
echo "     ||   \ |\ |XerXez77             C/ ,--___/"
echo "    _||   _||_||                 ~~~~  wwww~~~•"
echo "  ~~~~ wwwwww   w"
clear
echo "         __                   _=,_    _____________"
echo "      __/0 \_              o_/0 / \__| ANJING NGEWE|"
echo "      \_ __  \             \__ |  /   -------------"
echo "          /   \             = | -\ "
echo "    __   //\   \            /    '-,."
echo " __/o \-//--\   \_/         \ |_   _'-. /"
echo " \____  ___  \  |            |/ \_(   |'"
echo "     ||   \ |\ |XerXez77   C/ ,--___/"
echo "    _||   _||_||       ~~~~  wwww~~~•"
echo "  ~~~~ wwwwww   w"
